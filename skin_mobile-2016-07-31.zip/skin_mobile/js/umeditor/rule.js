define('umeditor/rule',['jquery','umeditor/umeditor'],function(require,exports,modules){
	var $ = require('jquery');
	exports.module = window.UM;
})