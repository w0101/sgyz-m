define(function(require,exports){
	var $=require("jquery");
	
	$("#BannerCarousel").carousel();
})