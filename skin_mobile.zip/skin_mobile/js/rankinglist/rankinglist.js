define(function(require,exports){
	var $=require("jquery");
	require("bootstrap")($);
	$("#BannerCarousel").carousel();
})